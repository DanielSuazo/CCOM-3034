#include "game.h"
#include <bits/stdc++.h>

void Table::setBoard() {
  std::srand(std::time(0));
  for(int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      push_front(Tile(i,j));
    }
  }
  std::random_shuffle(begin(), end());
}

std::list<Tile> Table::dealTiles() {
  std::list<Tile> tmp;
  for (int i = 0; i < 7; i++) {
    tmp.push_back(front());
    pop_front();
  }
  return tmp;
}

Player Player::operator=(std::list<Tile> list) {
  for (auto e : list) {
    push_back(e);
  }
  return *this;
}

bool Player::play(Table board) {
  bool final = false;
  for (auto &e : *this) {
    if (e.r == board.right()) {
      e.swap();
      board.playRight(e);
      this->remove(e);
      break;
    } else if (e.l == board.right()) {
      board.playRight(e);
      this->remove(e);
      break;
    } else if (e.r == board.left()) {
      board.playLeft(e);
      this->remove(e);
      break;
    } else if (e.l == board.left()) {
      e.swap();
      board.playLeft(e);
      this->remove(e);
      break;
    } else {
      final = true;
    }
  }
  return false;
}

void Table::display() {
  for (auto e : *this) {
    e.display();
  }
}

void Player::display() {
  for (auto e : *this) {
    e.display();
  }
}