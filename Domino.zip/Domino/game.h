#include<iostream>
#include<deque>
#include<list>

struct Tile {
    int l, r;
    Tile(int left, int right) : l(left), r(right) {}
    void swap() { std::swap(l,r); }
    void display() {std::cout << "[" << l << ":" << r << "]" << std::endl;}
};

class Table : private std::deque<Tile> {
  private:
  public:
    Table();
    int right() const { return back().r; }
    int left() const { return front().l; }
    void playRight(Tile t) { push_back(t); }
    void playLeft(Tile t) { push_front(t); }
    void setBoard();
    std::list<Tile> dealTiles();
    void display();
};

class Player : public std::list<Tile> {
  private:
  public:
    Player();
    Player operator=(std::list<Tile>);
    bool play(Table board);
    void display();
};