#include "game.h"

int main() {
  Table table;
  table.setBoard();
  Player p1, p2, p3, p4;
  p1 = table.dealTiles();
  p2 = table.dealTiles();
  p3 = table.dealTiles();
  p4 = table.dealTiles();
  bool stuck = false;
  while(!stuck){
    table.display();
    stuck = stuck && p1.play(table);
    stuck = stuck && p2.play(table);
    stuck = stuck && p3.play(table);
    stuck = stuck && p4.play(table);
    p1.display();
    p2.display();
    p3.display();
    p4.display();
  }
  
  if (p1.empty()){
    std::cout << "Player 1 wins!" << std::endl;
  } else if (p2.empty()) {
    std::cout << "Player 2 wins!" << std::endl;
  } else if (p3.empty()) {
    std::cout << "Player 3 wins!" << std::endl;
  } else if (p4.empty()) {
    std::cout << "Player 4 wins!" << std::endl;
  } else {
    std::cout << "F mano Yikes. Se tranco la cosa" << std::endl;
  }
}